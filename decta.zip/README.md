# Decta
This plugin add Custom Payment Gateways for WooCommerce. 

## Description
This version was tested with WooCommerce 3.4.5 and WordPress 4.9, also with WooCommerce 4.4.1 and WordPress 5.5. 

## Installation

1. Upload the plugin files to the /wp-content/plugins/(or upload the plugin decta.zip file using wp-admin).
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to 
    ```text
    WooCommerce > Setting > Payment Gateways
    ```
Then Active & configure WooCommerce Custom Payment Gateways
